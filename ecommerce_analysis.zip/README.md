# Análise de Vendas de E-commerce com SQL e Python

Este projeto demonstra como realizar uma análise completa de dados de vendas de um e-commerce fictício utilizando tecnologias gratuitas e locais. É ideal para iniciantes que desejam aprender análise de dados sem custos ou complexidade de configuração.

## 📊 Descrição do Projeto

O projeto analisa dados de vendas de um e-commerce fictício, explorando padrões de vendas, produtos mais populares, comportamento de clientes e tendências temporais. Todos os dados são gerados automaticamente e armazenados localmente.

## 🛠️ Tecnologias Utilizadas

- **Python 3.11+** - Linguagem principal
- **SQLite** - Banco de dados local (gratuito)
- **pandas** - Manipulação e análise de dados
- **matplotlib** - Visualizações básicas
- **seaborn** - Visualizações estatísticas
- **plotly** - Gráficos interativos
- **Faker** - Geração de dados fictícios

## 📁 Estrutura do Projeto

```
bigquery_ecommerce_analysis/
├── generate_data.py          # Script para gerar dados fictícios
├── load_data_to_sqlite.py    # Script para carregar dados no SQLite
├── sqlite_queries.py         # Consultas SQL organizadas
├── main.py                   # Script principal de análise
├── ecommerce_data.csv        # Dataset gerado (CSV)
├── ecommerce.db              # Banco de dados SQLite
├── plots/                    # Pasta com gráficos gerados
│   ├── faturamento_mensal.png
│   ├── top_produtos_vendidos.png
│   ├── faturamento_por_categoria.png
│   └── heatmap_vendas_dia_hora.png
├── insights.md               # Principais insights da análise
└── README.md                 # Este arquivo
```

## 🚀 Como Executar o Projeto

### Pré-requisitos

- Python 3.11 ou superior
- pip (gerenciador de pacotes do Python)

### Passo 1: Instalar Dependências

```bash
pip install pandas matplotlib seaborn plotly faker kaleido
```

### Passo 2: Gerar Dataset Fictício

```bash
python generate_data.py
```

Este comando criará o arquivo `ecommerce_data.csv` com 1000 pedidos fictícios.

### Passo 3: Carregar Dados no SQLite

```bash
python load_data_to_sqlite.py
```

Este comando criará o banco de dados `ecommerce.db` e carregará os dados do CSV.

### Passo 4: Executar Análise e Gerar Visualizações

```bash
python main.py
```

Este comando executará todas as análises e gerará os gráficos na pasta `plots/`.

## 📈 Análises Realizadas

1. **Faturamento Mensal** - Tendência de vendas ao longo do tempo
2. **Top 10 Produtos** - Produtos mais vendidos por faturamento
3. **Faturamento por Categoria** - Distribuição de vendas por categoria
4. **Média de Gasto por Cliente** - Valor médio gasto por cliente
5. **Heatmap de Vendas** - Padrão de pedidos por dia da semana e hora

## 📊 Visualizações Geradas

### Faturamento Mensal
![Faturamento Mensal](plots/faturamento_mensal.png)

### Top 10 Produtos Mais Vendidos
![Top Produtos](plots/top_produtos_vendidos.png)

### Faturamento por Categoria
![Faturamento por Categoria](plots/faturamento_por_categoria.png)

### Heatmap de Vendas por Dia/Hora
![Heatmap Vendas](plots/heatmap_vendas_dia_hora.png)

## 🔍 Principais Insights

- **Sazonalidade**: Identificação de períodos de alta e baixa demanda
- **Produtos Estratégicos**: Top 10 produtos que geram mais receita
- **Categorias Lucrativas**: Distribuição de faturamento por categoria
- **Comportamento Temporal**: Padrões de compra por dia da semana e horário

Para insights detalhados, consulte o arquivo [insights.md](insights.md).

## 📚 Aprendizados

Este projeto ensina:

- Geração de dados fictícios realistas
- Uso do SQLite para análise de dados
- Consultas SQL para extração de insights
- Limpeza e processamento de dados com pandas
- Criação de visualizações com matplotlib, seaborn e plotly
- Organização de código em classes e módulos
- Documentação de projetos de dados

## 🤝 Contribuições

Sinta-se à vontade para contribuir com melhorias:

1. Fork o projeto
2. Crie uma branch para sua feature (`git checkout -b feature/AmazingFeature`)
3. Commit suas mudanças (`git commit -m 'Add some AmazingFeature'`)
4. Push para a branch (`git push origin feature/AmazingFeature`)
5. Abra um Pull Request

## 📄 Licença

Este projeto é de código aberto e está disponível sob a licença MIT.

## 👨‍💻 Autor

Projeto criado como exemplo educacional para análise de dados com Python e SQL.

---

**Nota**: Este projeto utiliza apenas dados fictícios gerados automaticamente. Nenhum dado real de clientes ou vendas foi utilizado.

